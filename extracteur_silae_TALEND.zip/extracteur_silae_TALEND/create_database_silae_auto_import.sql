CREATE DATABASE IF NOT EXISTS silae_auto_import CHARACTER SET = 'utf8' COLLATE = 'utf8_general_ci';
use silae_auto_import;
source ./silae_dom.sql;